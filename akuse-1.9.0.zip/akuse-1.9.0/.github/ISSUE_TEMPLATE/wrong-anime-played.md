---
name: Wrong anime played
about: Report an incorrectly played anime.
title: ''
labels: wrong anime
assignees: ''

---

**Details**

Expected anime: [Enter the anilist id of the anime tha you wanted to play]
Wrong anime: [Enter the anilist id of the anime that is incorrectly playing]
Language: [Enter the language in which the issue occurs]
Dub: [Enter whether this issue happens when you try to play the sub or the dub version]

**Additional Information**
Enter any additional information that might help to better understand the issue.
