
export const SPONSOR_URL = 'https://ko-fi.com/aleganza';
export const OPEN_NEW_ISSUE_URL = 'https://github.com/aleganza/akuse/issues/new';
export const EPISODES_INFO_URL = 'https://api.ani.zip/mappings?anilist_id=';
