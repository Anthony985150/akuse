
// declare global {
//   interface Window {
//     electron: {
//       ipcRenderer: any;
//       store: {
//         get: (key: string) => any;
//         set: (key: string, val: any) => void;
//         // any other methods you've defined...
//       };
//       anilist: any
//     };
//   }
// }

// export {};
